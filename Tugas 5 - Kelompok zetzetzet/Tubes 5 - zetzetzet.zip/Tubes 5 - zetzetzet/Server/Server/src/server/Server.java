/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.sql.SQLException;
import java.io.IOException;
import java.io.PrintStream;
import java.net.*;
/**
 *
 * @author Akbar
 */
public class Server{

    /**
     * @param args the command line arguments
     */
    public static final int maxclient=10;
    public static clientthread[] clients2=new clientthread[maxclient];
    public static ServerSocket ss=null;
    public static Socket clientsocket=null;
    public static String t;
    public static ArrayList<String> w=new ArrayList<String>();
    /*
    public void run()
    {
        System.out.println("jika ada pesan exception nullpointer di line 33, abaikan saja");
        String prev=new String("");
        int i=0;
        while (true)
        {
            
            if (!clientthread.currentread.equals(prev)) {w.add(clientthread.currentread);i++;};
            System.out.println(w.get(i-1));
            prev=clientthread.currentread;
        }
           
        
    }*/
    public static void main(String[] args) {
        
        // TODO code application logic here
        Connection con=null;
        ResultSet rs=null;
        Statement st=null;
        //(new Thread(new Server())).start();
        try
        {
            ss=new ServerSocket(2000);
        }
        catch(IOException e)
        {
            System.out.println("Exception ketika menginisialisasi objek serversocket: "+e);
        }
        
        while (true)
        {
            try
            {
            clientsocket=ss.accept();
            int i=0;
            for (i=0;i<maxclient;i++)
                {
                    
                    if (clients2[i] == null) {(new clientthread(clientsocket,clients2)).start();break;};
                             
                }
            if (i == maxclient)
            {
                PrintStream os = new PrintStream(clientsocket.getOutputStream());
                os.println("Server penuh");
                os.close();
                clientsocket.close();
            };
           
            }
            catch(Exception e)
            {
                System.out.println("Exception terjadi ketika menghidupkan thread: "+e);
            }

        }
        
          
    }
}
