/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package server;
import cipherutils.CipherUtils;
import java.util.ArrayList;
import java.net.Socket;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Akbar
 */
public class clientthread extends Thread{
    
    public DataInputStream is=null;
    public PrintStream os=null;
    public Socket clientsocket=null;
    public clientthread[] clients;
    public int maxclient;
    public Connection con;
    public Statement st;
    public ResultSet rs;
    public static String currentread;
    public static ArrayList<String> username=new ArrayList<String>();
    public static ArrayList<String> password=new ArrayList<String>();
    
    

    
    public clientthread(Socket s, clientthread[] a)
    {
        this.clientsocket=s;
        this.clients=a;
        maxclient=a.length;
    }
    
    public void run()
    {
        int maxclient=this.maxclient;
        clientthread[] clients=this.clients;
        
        try
        {
         Class.forName("com.mysql.jdbc.Driver");
         con=DriverManager.getConnection("jdbc:mysql://localhost:3306/progin_405_13510099","progin","progin");
         if (username.isEmpty() && password.isEmpty())
         {
            st=con.createStatement();
            rs=st.executeQuery("SELECT * FROM user1");     
            while (rs.next())
            {
                 username.add(rs.getString("username"));
                 password.add(rs.getString("password"));
            }
         };
        }
        catch(Exception e)
        {
            System.out.println("eksepsyon waktu konek: "+e);
        }
        
        try
        {
            is=new DataInputStream(clientsocket.getInputStream());
            os=new PrintStream(clientsocket.getOutputStream());
            
            while (true)
            {
                String line=is.readLine();
                currentread=line;
                
                if (line.startsWith("LOGIN")) //buat login
                    {
                        String[] temp=line.split(" "); //pendekripsian
                        temp[1]=CipherUtils.decrypt(temp[1]);
                        temp[2]=CipherUtils.decrypt(temp[2]);
                        if (username.contains(temp[1]) && password.contains(temp[2]))
                                {os.println("LOGINSUCC: "+temp[1]);} else {os.println("LOGINFAIL: "+temp[1]);};
                    };
                    
                if (line.startsWith("MODIFY")) //buat ganti status
                {
                    String[] temp2=line.split(" ");
                    String status=new String("");
                    String gantijadi=new String("");
                    try
                    {
                        st=con.createStatement();
                        rs=st.executeQuery("SELECT status FROM tugas1 WHERE ID_tugas='"+temp2[1]+"';");
                        rs.next();
                        status=rs.getString("status");
                        if (status.equals("sudah"))
                            {
                                gantijadi="belum";
                            } 
                        else
                            {
                                gantijadi="sudah";
                            };
                       st.executeUpdate("UPDATE tugas1 SET status='"+gantijadi+"' WHERE ID_tugas='"+temp2[1]+"';");
                    }
                    catch(Exception e)
                    {
                        System.out.println("Exception terjadi ketika akan melakukan pengubahan status tugas: "+e);
                    }
                };
                
                if (line.startsWith("LOGOUT")) //buat logout
                    {os.println("Logout akan dilakukan....");break;};
                
            }
            
            os.close();
            is.close();
            clientsocket.close();
        }
        catch(IOException e)
        {
            System.out.println("Error di run(): "+e);
        }
    }
    
    
    
   
}
